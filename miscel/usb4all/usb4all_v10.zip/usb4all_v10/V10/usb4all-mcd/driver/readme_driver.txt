﻿Das sind die USB-Treiber.

Es gibt zwei unterschiedliche Versionen. 

Die eine (driver_98_me_2k) ist ein erprobter älterer Treiber, der noch Windows98/me unterstützt und auch unter Windows2000 stabil läuft.

Die andere (driver_2k_xp_Vista) ist neuer und unterstützt Windows2000, WindowsXP, Windows_Vista32 sowie Windows_Vista64. Ich habe keine Erfahrung mit der Nutzung unter Vista und bitte um Rückmeldungen.

sprut
02.02.2008
