The capacitor C8 should have a value of at least 1 uF (10 uF is better).

sprut